#!/usr/bin/env python
# scripts/sweep_hazard.py
import os, argparse, numpy as np, pandas as pd


def load_probs(path):
    df = pd.read_csv(path, parse_dates=["ts"]).set_index("ts").sort_index()
    assert {"p","y"} <= set(df.columns), f"missing columns in {path}: {df.columns}"
    df["y"] = df["y"].fillna(0).astype(int)
    return df


def build_alert_series(p, thr_on, thr_off=None, ema_span=1, k=1):
    """Return boolean Series of alerts (per minute) given p in [0,1].
       - ema_span>1: smooth p with EMA(span)
       - k>=1: require k consecutive minutes above thr_on
       - hysteresis: use thr_off<thr_on to turn signal off
    """
    s = p.copy()
    if ema_span and ema_span > 1:
        s = s.ewm(span=ema_span, adjust=False).mean()

    on = s >= thr_on
    if k > 1:
        # rolling k-consecutive filter
        on = on.rolling(k, min_periods=k).sum().fillna(0).astype(int) == k

    if thr_off is None or thr_off >= thr_on:
        return on.astype(bool)

    # hysteresis: keep "on" until s falls below thr_off
    out = pd.Series(False, index=s.index)
    state = False
    for t, val in s.items():
        if not state:
            if val >= thr_on:
                state = True
        else:
            if val < thr_off:
                state = False
        out.loc[t] = state
    if k > 1:
        # re-apply k-confirmation only to rising edges
        rising = (out & ~out.shift(1).fillna(False))
        out = rising.rolling(k, min_periods=k).sum().fillna(0).astype(int) == k
    return out.astype(bool)


def sparsify_alerts(alert_bool, min_sep_min=30):
    """Turn per-minute bools into sparse alert times with cooldown."""
    idx = alert_bool.index[alert_bool]
    alerts, last = [], None
    delta = pd.Timedelta(minutes=min_sep_min)
    for t in idx:
        if last is None or t - last >= delta:
            alerts.append(t)
            last = t
    return pd.DatetimeIndex(alerts)


def episodes_from_y(y):
    """Collapse contiguous y==1 minutes into positive 'episodes' (start times)."""
    g = (y.ne(y.shift(1))).cumsum()
    blocks = y.groupby(g)
    starts = [grp.index[0] for val, grp in blocks if val == 1]
    return pd.DatetimeIndex(starts)


def score(df, thr_on, thr_off=None, ema_span=1, k=1, min_sep=30):
    y = df["y"]
    p = df["p"]
    alert_bool = build_alert_series(p, thr_on, thr_off, ema_span, k)
    A = sparsify_alerts(alert_bool, min_sep)
    n_days = max((df.index[-1] - df.index[0]).total_seconds() / 86400.0, 1e-9)

    # positive episodes (minute-level hazard episodes, not actual flips)
    starts = episodes_from_y(y)
    if len(starts) == 0:
        return dict(
            thr_on=thr_on,
            thr_off=thr_off,
            ema_span=ema_span,
            k=k,
            min_sep=min_sep,
            alerts=len(A),
            fa_per_day=np.nan,
            tp=0,
            coverage=0.0,
        )

    # count TP if any alert occurs within the episode window (at/after start)
    # (strict: use alerts at/after episode start; generous: allow tiny early alerts with -5min)
    tp_flags = []
    a_i = 0
    for s in starts:
        # jump a_i to first alert >= s
        while a_i < len(A) and A[a_i] < s:
            a_i += 1
        tp_flags.append(a_i < len(A) and A[a_i] >= s)
    tp = int(np.sum(tp_flags))
    coverage = tp / len(starts)

    # false alarms = alerts that do NOT coincide with any episode
    # mark all episode spans (from start until y returns to 0)
    g = (y.ne(y.shift(1))).cumsum()
    spans = [(grp.index[0], grp.index[-1]) for val, grp in y.groupby(g) if val == 1]

    def in_any_span(t):
        for a, b in spans:
            if a <= t <= b:
                return True
        return False

    fa = sum(1 for t in A if not in_any_span(t))
    fa_per_day = fa / n_days

    return dict(
        thr_on=thr_on,
        thr_off=thr_off,
        ema_span=ema_span,
        k=k,
        min_sep=min_sep,
        alerts=len(A),
        fa_per_day=fa_per_day,
        tp=tp,
        coverage=coverage,
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--probs_csv", default="outputs/hazard/hazard_probs.csv")
    ap.add_argument("--out_csv", default="outputs/hazard/hazard_sweep.csv")
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.out_csv), exist_ok=True)
    df = load_probs(args.probs_csv)

    thr_grid = np.round(np.linspace(0.30, 0.90, 25), 3)
    delta = 0.10  # hysteresis gap: thr_off = thr_on - delta
    emas = [1, 3, 5]  # 1=None, 3~short, 5~smoother
    ks = [1, 2]  # require consecutive bars
    seps = [30, 60]  # cooldown

    rows = []
    for thr in thr_grid:
        thr_off = max(0.0, thr - delta)
        for ema in emas:
            for k in ks:
                for sep in seps:
                    rows.append(score(df, thr, thr_off, ema, k, sep))

    out = pd.DataFrame(rows).sort_values(["fa_per_day", "coverage", "thr_on"], ascending=[True, False, True])
    out.to_csv(args.out_csv, index=False)
    # print the best few under sane FA budget
    cand = out[out.fa_per_day <= 2.0].head(12)
    print("\nTop candidates (fa_per_day ≤ 2):")
    print(cand.to_string(index=False) if len(cand) else "None under 2 FA/day; raise thr or k/ema/min_sep.")
    print(f"\nSaved full sweep to {args.out_csv}")


if __name__ == "__main__":
    main()

