import pandas as pd


def gate_timeseries(p: pd.Series, thr: float, k: int, ema_span: int, min_sep_min: int) -> pd.DatetimeIndex:
    """Generate sparse alert times from a per-minute probability series.

    - p: minute-indexed probabilities in [0, 1]
    - thr: on-threshold
    - k: require k consecutive minutes above threshold
    - ema_span: optional EMA smoothing span (<=1 disables smoothing)
    - min_sep_min: cooldown between successive alerts
    """
    p = p.sort_index()
    s = p.ewm(span=ema_span, adjust=False).mean() if ema_span and ema_span > 1 else p
    on = (s >= thr).rolling(k, min_periods=k).sum().fillna(0).astype(int) == k
    idx = on.index[on]
    out: list[pd.Timestamp] = []
    last = None
    cooldown = pd.Timedelta(minutes=int(min_sep_min))
    for t in idx:
        if last is None or t - last >= cooldown:
            out.append(t)
            last = t
    return pd.DatetimeIndex(out)

